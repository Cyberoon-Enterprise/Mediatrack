var api_folder="/api/";
/*Don't change it unless you really know what you are doing*/
